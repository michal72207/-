using System.Security.Claims;
using GatherUp.API.DTOs;
using GatherUp.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GatherUp.API.Controllers
{
    /// <summary>ניהול אירועים — יצירה, קריאה, עדכון, מחיקה, הזמנות.</summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EventsController : ControllerBase
    {
        private readonly EventService _eventService;

        public EventsController(EventService eventService)
        {
            _eventService = eventService;
        }

        /// <summary>מחזיר את כל האירועים.</summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll() =>
            Ok((await _eventService.GetAllAsync()).Select(EventMapper.ToResponse));

        /// <summary>מחזיר אירוע לפי מזהה.</summary>
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id) =>
            Ok(EventMapper.ToResponse(await _eventService.GetByIdAsync(id)));

        /// <summary>מחזיר את האירועים שבניהול המנהל המחובר.</summary>
        [HttpGet("my/managed")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMyManagedEvents() =>
            Ok((await _eventService.GetEventsByManagerAsync(GetCallerId())).Select(EventMapper.ToResponse));

        /// <summary>מחזיר את האירועים שהמשתתף המחובר רשום אליהם.</summary>
        [HttpGet("my/participating")]
        [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMyParticipatingEvents() =>
            Ok((await _eventService.GetEventsByParticipantAsync(GetCallerId())).Select(EventMapper.ToResponse));

        /// <summary>מחזיר את האירועים של בעל אירוע לפי מזהה.</summary>
        [HttpGet("host/{hostId:int}")]
        [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetByHost(int hostId) =>
            Ok((await _eventService.GetEventsByHostAsync(hostId)).Select(EventMapper.ToResponse));

        /// <summary>יצירת אירוע חדש. שלב א' — כולל שאלון מקדים אופציונלי.</summary>
        [HttpPost]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
        public async Task<IActionResult> Create([FromBody] CreateEventRequest request)
        {
            var ev = await _eventService.CreateEventAsync(
                request.Name, request.Date, request.Location,
                request.PricePerParticipant, request.EventManagerId, request.EventHostId,
                request.InvitationMessage, request.PaymentDetails, request.PreliminaryPollId);

            return CreatedAtAction(nameof(GetById), new { id = ev.Id }, EventMapper.ToResponse(ev));
        }

        /// <summary>עדכון פרטי אירוע. שלב ז' — מפעיל התראה לכל המנויים.</summary>
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateEventRequest request)
        {
            if (!await _eventService.IsEventManagerAsync(id, GetCallerId()))
                return Forbid();

            await _eventService.UpdateDetailsAsync(id, request.Name, request.Location,
                request.PricePerParticipant, request.InvitationMessage, request.PaymentDetails);

            return Ok(EventMapper.ToResponse(await _eventService.GetByIdAsync(id)));
        }

        /// <summary>מחיקת אירוע.</summary>
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete(int id)
        {
            if (!await _eventService.IsEventManagerAsync(id, GetCallerId()))
                return Forbid();

            await _eventService.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>שלב ג' — שליחת הזמנות למשתתפים ממתינים עם תוכן מנהל ופרטי תשלום.</summary>
        [HttpPost("{id:int}/invitations")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SendInvitations(int id, [FromBody] SendInvitationsRequest request)
        {
            if (!await _eventService.IsEventManagerAsync(id, GetCallerId()))
                return Forbid();

            await _eventService.SendInvitationsAsync(id, request.RegistrationLink);
            return NoContent();
        }

        /// <summary>שלב ג' — שליחת הזמנה נפרדת לבעל האירוע.</summary>
        [HttpPost("{id:int}/host-invitation")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SendHostInvitation(int id, [FromBody] SendHostInvitationRequest request)
        {
            if (!await _eventService.IsEventManagerAsync(id, GetCallerId()))
                return Forbid();

            await _eventService.SendHostInvitationAsync(id, request.HostMessageContent);
            return NoContent();
        }

        /// <summary>שלב ג' — תזמון הזמנה לבעל האירוע.</summary>
        [HttpPost("{id:int}/host-invitation/schedule")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ScheduleHostInvitation(int id, [FromBody] ScheduleHostInvitationRequest request)
        {
            if (!await _eventService.IsEventManagerAsync(id, GetCallerId()))
                return Forbid();

            await _eventService.ScheduleHostInvitationAsync(id, request.ScheduledAt);
            return NoContent();
        }

        private int GetCallerId() =>
            int.TryParse(User.FindFirstValue("userId"), out int id) ? id : 0;
    }
}
