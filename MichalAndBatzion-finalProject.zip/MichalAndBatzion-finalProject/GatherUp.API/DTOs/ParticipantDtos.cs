using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GatherUp.Core.DO;

namespace GatherUp.API.DTOs
{
    public record ParticipantResponse(
        int                     Id,
        string                  Name,
        string                  Email,
        bool?                   IsAttending,
        bool                    HasPaid,
        decimal                 AmountContributed,
        List<MailingPreference> MailingPreferences
    );

    public record CreateParticipantRequest(
        [Required, MinLength(2)] string  Name,
        [Required, EmailAddress] string  Email,
        List<MailingPreference>?         MailingPreferences
    );

    public record UpdateParticipantRequest(
        string?                  Name,
        string?                  Email,
        List<MailingPreference>? MailingPreferences
    );

    // שלב ד' — המשתתף בוחר העדפות דיוור בעת אישור הגעה
    public record ConfirmAttendanceRequest(
        [Required] bool                  IsAttending,
        List<MailingPreference>?         SelectedPreferences
    );

    public static class ParticipantMapper
    {
        public static ParticipantResponse ToResponse(Participant p) => new(
            p.Id, p.Name, p.Email, p.IsAttending,
            p.HasPaid, p.AmountContributed, p.MailingPreferences);

        public static Participant ToEntity(CreateParticipantRequest r, int newId) => new()
        {
            Id                 = newId,
            Name               = r.Name,
            Email              = r.Email,
            MailingPreferences = r.MailingPreferences ?? new List<MailingPreference>()
        };
    }
}
