using System;
using System.IO;
using System.Threading.Tasks;
using GatherUp.Core.Interfaces;

namespace GatherUp.Infrastructure.Data
{
    public class FileEmailService : IEmailService
    {
        private readonly string _logFilePath;

        public FileEmailService(string logFolder)
        {
            if (!Directory.Exists(logFolder))
                Directory.CreateDirectory(logFolder);
            _logFilePath = Path.Combine(logFolder, "emails.log");
        }

        public async Task SendAsync(string toEmail, string subject, string body)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
                throw new ArgumentException("Email recipient cannot be empty", nameof(toEmail));
            if (string.IsNullOrWhiteSpace(subject))
                throw new ArgumentException("Email subject cannot be empty", nameof(subject));
            if (string.IsNullOrWhiteSpace(body))
                throw new ArgumentException("Email body cannot be empty", nameof(body));

            try
            {
                string safeEmail   = toEmail.Replace("\n", " ").Replace("\r", " ");
                string safeSubject = subject.Replace("\n", " ").Replace("\r", " ");
                string safeBody    = body.Replace("\r", " ");
                string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] To: {safeEmail} | Subject: {safeSubject}\n{safeBody}\n{new string('-', 80)}\n";
                await File.AppendAllTextAsync(_logFilePath, entry);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to send email to {toEmail}", ex);
            }
        }
    }
}
