// Use GatherUp.Core.Exceptions.UnauthorizedOperationException directly.
