// Use GatherUp.Core.Exceptions.ReceiptLockedException directly.
