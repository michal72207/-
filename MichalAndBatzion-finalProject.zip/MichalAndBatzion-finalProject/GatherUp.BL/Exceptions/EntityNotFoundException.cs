// Use GatherUp.Core.Exceptions.EntityNotFoundException directly.
