using GatherUp.API.DTOs;
using GatherUp.BL;
using GatherUp.Core.DO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GatherUp.API.Controllers
{
    /// <summary>ניהול פיננסי — תשלומים, ספקים, קבלות, סיכום תקציב. שלב ו'.</summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Manager")]
    public class FinancialController : ControllerBase
    {
        private readonly FinanceService _financeService;

        public FinancialController(FinanceService financeService)
        {
            _financeService = financeService;
        }

        #region Payments

        /// <summary>רישום תשלום משתתף — התקציב הנכנס גדל דינמית.</summary>
        [HttpPost("payment")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> RegisterPayment([FromBody] RegisterPaymentRequest request)
        {
            await _financeService.RegisterPaymentAsync(request.ParticipantId, request.EventId, request.Amount);
            return NoContent();
        }

        /// <summary>שלב ז' — שליחת תזכורות תשלום למשתתפים שלא שילמו.</summary>
        [HttpPost("event/{eventId:int}/reminders")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> SendReminders(int eventId, [FromBody] SendRemindersRequest request)
        {
            await _financeService.SendPaymentRemindersAsync(eventId, request.BankDetails);
            return NoContent();
        }

        #endregion

        #region Vendors

        /// <summary>שלב ו' — הוספת ספק לאירוע; התקציב היוצא גדל.</summary>
        [HttpPost("vendor")]
        [ProducesResponseType(typeof(VendorResponse), StatusCodes.Status201Created)]
        public async Task<IActionResult> AddVendor([FromBody] AddVendorRequest request)
        {
            var vendor = await _financeService.AddVendorToEventAsync(
                request.EventId, request.Name, request.InitialDebt);

            return CreatedAtAction(nameof(GetVendor), new { vendorId = vendor.Id },
                new VendorResponse(vendor.Id, vendor.Name, vendor.AmountOwed, vendor.ReceiptIds));
        }

        /// <summary>מחזיר ספק לפי מזהה.</summary>
        [HttpGet("vendor/{vendorId:int}")]
        [ProducesResponseType(typeof(VendorResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetVendor(int vendorId)
        {
            var v = await _financeService.GetVendorByIdAsync(vendorId);
            return Ok(new VendorResponse(v.Id, v.Name, v.AmountOwed, v.ReceiptIds));
        }

        /// <summary>מחזיר את כל הספקים.</summary>
        [HttpGet("vendor")]
        [ProducesResponseType(typeof(IEnumerable<VendorResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllVendors() =>
            Ok((await _financeService.GetAllVendorsAsync())
                .Select(v => new VendorResponse(v.Id, v.Name, v.AmountOwed, v.ReceiptIds)));

        /// <summary>הוספת חוב נוסף לספק קיים.</summary>
        [HttpPost("vendor/{vendorId:int}/debt")]
        [ProducesResponseType(typeof(VendorResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> AddDebt(int vendorId, [FromBody] AddVendorDebtRequest request)
        {
            await _financeService.AddVendorDebtAsync(vendorId, request.Amount);
            var v = await _financeService.GetVendorByIdAsync(vendorId);
            return Ok(new VendorResponse(v.Id, v.Name, v.AmountOwed, v.ReceiptIds));
        }

        /// <summary>מחיקת ספק.</summary>
        [HttpDelete("vendor/{vendorId:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteVendor(int vendorId)
        {
            await _financeService.DeleteVendorAsync(vendorId);
            return NoContent();
        }

        #endregion

        #region Receipts

        /// <summary>שלב ו' — צירוף קבלה דיגיטלית לספק; ננעלת ולא ניתנת לשינוי.</summary>
        [HttpPost("vendor/{vendorId:int}/receipt")]
        [ProducesResponseType(typeof(ReceiptResponse), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> AddReceipt(int vendorId, [FromBody] AddReceiptRequest request)
        {
            var receipt = new Receipt
            {
                Id            = request.Id,
                VendorId      = vendorId,
                ReceiptNumber = request.ReceiptNumber,
                FilePath      = request.FilePath,
                Amount        = request.Amount,
                Date          = request.Date
            };

            await _financeService.AddReceiptAsync(receipt, vendorId);

            return StatusCode(StatusCodes.Status201Created,
                new ReceiptResponse(receipt.Id, receipt.VendorId, receipt.ReceiptNumber,
                                    receipt.FilePath, receipt.Amount, receipt.Date));
        }

        /// <summary>מחזיר את כל הקבלות של אירוע, ממוינות לפי תאריך יורד.</summary>
        [HttpGet("event/{eventId:int}/receipts")]
        [ProducesResponseType(typeof(IEnumerable<ReceiptSortedResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetReceiptsSorted(int eventId) =>
            Ok((await _financeService.GetAllReceiptsSortedAsync(eventId))
                .Select(r => new ReceiptSortedResponse(r.ReceiptId, r.Amount, r.Date)));

        #endregion

        #region Summary

        /// <summary>סיכום פיננסי מלא לאירוע.</summary>
        [HttpGet("event/{eventId:int}/summary")]
        [ProducesResponseType(typeof(FinancialSummaryResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSummary(int eventId)
        {
            var s = await _financeService.GetFinancialSummaryAsync(eventId);
            return Ok(new FinancialSummaryResponse(
                s.Payers.Select(p  => new PayerResponse(p.Participant.Id, p.Participant.Name, p.Amount)).ToList(),
                s.TotalIncome,
                s.Vendors.Select(v => new VendorResponse(v.Vendor.Id, v.Vendor.Name, v.Owed, v.Vendor.ReceiptIds)).ToList(),
                s.TotalExpenses,
                s.Balance));
        }

        /// <summary>יתרה נטו (הכנסות פחות הוצאות) לאירוע.</summary>
        [HttpGet("event/{eventId:int}/balance")]
        [ProducesResponseType(typeof(decimal), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetBalance(int eventId) =>
            Ok(await _financeService.GetNetBalanceAsync(eventId));

        #endregion
    }
}
