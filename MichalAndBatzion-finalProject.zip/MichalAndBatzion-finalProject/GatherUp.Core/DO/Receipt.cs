using System;
using System.Xml.Serialization;
using GatherUp.Core.Interfaces;

namespace GatherUp.Core.DO
{
    // ReceiptDetails — ישות קפואה (Immutable) לפי המפרט.
    // כל המאפיינים הם init-only — לא ניתן לשנותם לאחר האתחול.
    // ReceiptRepository אוכף immutability נוספת ע"י זריקת חריגה בכל ניסיון Update/Delete.
    public sealed class Receipt : IEntity
    {
        // Id חייב להיות settable כדי לאפשר XML deserialization
        [XmlAttribute("id")]
        public int Id { get; set; }

        public int      VendorId      { get; init; }
        public string   ReceiptNumber { get; init; } = string.Empty;
        public string   FilePath      { get; init; } = string.Empty;
        public decimal  Amount        { get; init; }
        public DateTime Date          { get; init; }
    }
}
