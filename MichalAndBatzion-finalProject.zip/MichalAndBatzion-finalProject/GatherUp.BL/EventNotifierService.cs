using System.Linq;
using System.Threading.Tasks;
using GatherUp.Core.DO;
using GatherUp.Core.Interfaces;

namespace GatherUp.BL
{
    // שלב ז' — מנוע התראות אסינכרוני: מפיץ מיילים אוטומטיים למנהלים ולמשתתפים
    public class EventNotifierService : IEventNotifier
    {
        private readonly IRepository<Participant>  _participantRepo;
        private readonly IRepository<EventManager> _managerRepo;
        private readonly IRepository<Event>        _eventRepo;
        private readonly IEmailService             _emailService;

        public EventNotifierService(
            IRepository<Participant>  participantRepo,
            IRepository<EventManager> managerRepo,
            IRepository<Event>        eventRepo,
            IEmailService             emailService)
        {
            _participantRepo = participantRepo;
            _managerRepo     = managerRepo;
            _eventRepo       = eventRepo;
            _emailService    = emailService;
        }

        public async Task OnAttendanceConfirmedAsync(int participantId, int eventId)
        {
            var ev      = await _eventRepo.GetByIdAsync(eventId);
            var manager = (await _managerRepo.GetAllAsync()).FirstOrDefault(m => m.Id == ev.EventManagerId);
            var participant = (await _participantRepo.GetAllAsync()).FirstOrDefault(p => p.Id == participantId);

            if (manager == null || participant == null) return;

            try
            {
                await _emailService.SendAsync(manager.Email, "אישור הגעה התקבל",
                    $"שלום {manager.Name},\n\nהמשתתף {participant.Name} אישר הגעה לאירוע {ev.Name}" +
                    $"\n\nסטטוס: {(participant.IsAttending == true ? "✅ מגיע/ה" : "❌ לא מגיע/ה")}\n\nבברכה,\nמערכת GatherUp");

                if (participant.MailingPreferences.Contains(MailingPreference.AttendanceConfirmed))
                {
                    await _emailService.SendAsync(participant.Email, "אישור הגעה נרשם",
                        $"שלום {participant.Name},\n\nאישור ההגעה שלך לאירוע {ev.Name} נרשם בהצלחה.\n\nבברכה,\nמערכת GatherUp");
                }
            }
            catch { }
        }

        public async Task OnPaymentReceivedAsync(int participantId, int eventId)
        {
            var ev      = await _eventRepo.GetByIdAsync(eventId);
            var manager = (await _managerRepo.GetAllAsync()).FirstOrDefault(m => m.Id == ev.EventManagerId);
            var participant = (await _participantRepo.GetAllAsync()).FirstOrDefault(p => p.Id == participantId);

            if (manager == null || participant == null) return;

            try
            {
                await _emailService.SendAsync(manager.Email, "תשלום התקבל",
                    $"שלום {manager.Name},\n\nהמשתתף {participant.Name} שילם עבור אירוע {ev.Name}" +
                    $"\n\nסכום: {participant.AmountContributed}₪\n\nבברכה,\nמערכת GatherUp");

                if (participant.MailingPreferences.Contains(MailingPreference.PaymentReceived))
                {
                    await _emailService.SendAsync(participant.Email, "אישור תשלום",
                        $"שלום {participant.Name},\n\nתשלומך עבור אירוע {ev.Name} נרשם בהצלחה.\n\nסכום: {participant.AmountContributed}₪\n\nבברכה,\nמערכת GatherUp");
                }
            }
            catch { }
        }

        public async Task OnPollAnsweredAsync(int participantId, int pollId)
        {
            try
            {
                var ev = (await _eventRepo.GetAllAsync()).FirstOrDefault(e => e.PollIds.Contains(pollId));
                if (ev == null) return;

                var manager = (await _managerRepo.GetAllAsync()).FirstOrDefault(m => m.Id == ev.EventManagerId);
                if (manager == null) return;

                var who = (await _participantRepo.GetAllAsync()).FirstOrDefault(p => p.Id == participantId);
                if (who == null) return;

                await _emailService.SendAsync(manager.Email, "תשובה חדשה לסקר",
                    $"שלום {manager.Name},\n\nהמשתתף {who.Name} ענה על סקר {pollId} באירוע {ev.Name}.\n\nבברכה,\nמערכת GatherUp");
            }
            catch { }
        }

        public async Task OnPollCreatedAsync(int pollId, int eventId)
        {
            try
            {
                var ev = await _eventRepo.GetByIdAsync(eventId);
                var participants = (await _participantRepo.GetAllAsync())
                    .Where(p => ev.ParticipantIds.Contains(p.Id)
                        && p.MailingPreferences.Contains(MailingPreference.PollCreated));

                foreach (var p in participants)
                    await _emailService.SendAsync(p.Email, "סקר חדש נוצר",
                        $"שלום {p.Name},\n\nנוצר סקר חדש באירוע {ev.Name}.\n\nעל מנת להשתתף בסקר, בקר ב-http://gatherup.app/polls.html\n\nבברכה,\nמערכת GatherUp");
            }
            catch { }
        }

        public async Task OnEventDetailsChangedAsync(int eventId)
        {
            try
            {
                var ev = await _eventRepo.GetByIdAsync(eventId);
                var participants = (await _participantRepo.GetAllAsync())
                    .Where(p => ev.ParticipantIds.Contains(p.Id)
                        && p.MailingPreferences.Contains(MailingPreference.EventChanges));

                foreach (var p in participants)
                    await _emailService.SendAsync(p.Email, "פרטי האירוע עודכנו",
                        $"שלום {p.Name},\n\nחל עדכון בפרטי האירוע {ev.Name}.\n\nתאריך: {ev.Date:dd/MM/yyyy}\n" +
                        $"מיקום: {ev.Location ?? "טרם נקבע"}\nמחיר: {ev.PricePerParticipant}₪\n\nבברכה,\nמערכת GatherUp");
            }
            catch { }
        }
    }
}
