using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using GatherUp.Core.Interfaces;

namespace GatherUp.Core.DO
{
    public class Event : IEntity
    {
        [XmlAttribute("id")]
        public int Id { get; set; }

        public string Name     { get; set; } = string.Empty;
        public DateTime Date   { get; set; }
        public string? Location { get; set; }
        public decimal PricePerParticipant { get; set; }

        public int EventManagerId { get; set; }
        public int EventHostId    { get; set; }

        // מזהה של שאלון מקדים (שלב א') — null אם אין
        public int? PreliminaryPollId { get; set; }

        // תוכן הזמנה מנוסח ע"י המנהל (שלב ג')
        public string? InvitationMessage { get; set; }

        // פרטי תשלום (שלב ג')
        public string? PaymentDetails { get; set; }

        // תזמון הזמנה לבעל האירוע (שלב ג') — null = לא תוזמן
        public DateTime? HostInvitationScheduledAt { get; set; }

        // האם ההזמנה לבעל האירוע כבר נשלחה
        public bool HostInvitationSent { get; set; }

        public List<int> ParticipantIds { get; set; } = new();
        public List<int> VendorIds      { get; set; } = new();
        public List<int> PollIds        { get; set; } = new();

        public EventStatus Status { get; set; } = EventStatus.Draft;
    }

    public enum EventStatus
    {
        Draft = 0,
        Planning = 1,
        InvitationsSent = 2,
        Finalized = 3
    }
}
