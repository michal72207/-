using GatherUp.API.DTOs;
using GatherUp.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GatherUp.API.Controllers
{
    /// <summary>קריאת רשימת משתתפים — לשימוש פנימי בממשק.</summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PersonController : ControllerBase
    {
        private readonly PersonService _personService;

        public PersonController(PersonService personService)
        {
            _personService = personService;
        }

        /// <summary>מחזיר את כל המשתתפים הרשומים.</summary>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ParticipantResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll() =>
            Ok((await _personService.GetAllParticipantsAsync()).Select(ParticipantMapper.ToResponse));

        /// <summary>מחזיר משתתף לפי מזהה.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id) =>
            Ok(ParticipantMapper.ToResponse(await _personService.GetParticipantByIdAsync(id)));
    }
}
