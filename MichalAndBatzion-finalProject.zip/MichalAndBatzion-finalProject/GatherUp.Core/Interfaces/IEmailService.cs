using System.Threading.Tasks;

namespace GatherUp.Core.Interfaces
{
    public interface IEmailService
    {
        Task SendAsync(string toEmail, string subject, string body);
    }
}
