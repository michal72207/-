using System.Security.Claims;
using GatherUp.API.DTOs;
using GatherUp.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GatherUp.API.Controllers
{
    /// <summary>ניהול משתתפים — הוספה, עדכון, אישור הגעה.</summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ParticipantsController : ControllerBase
    {
        private readonly ParticipantService _participantService;
        private readonly PersonService      _personService;

        public ParticipantsController(
            ParticipantService participantService,
            PersonService      personService)
        {
            _participantService = participantService;
            _personService      = personService;
        }

        /// <summary>מחזיר משתתף לפי מזהה.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id) =>
            Ok(ParticipantMapper.ToResponse(await _personService.GetParticipantByIdAsync(id)));

        /// <summary>מחזיר את כל המשתתפים של אירוע.</summary>
        [HttpGet("event/{eventId:int}")]
        [ProducesResponseType(typeof(IEnumerable<ParticipantResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetByEvent(int eventId) =>
            Ok((await _participantService.GetEventParticipantsAsync(eventId)).Select(ParticipantMapper.ToResponse));

        /// <summary>מחזיר משתתף לפי כתובת מייל.</summary>
        [HttpGet("byEmail")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetByEmail([FromQuery] string email)
        {
            var p = await _participantService.GetByEmailAsync(email);
            return p is null
                ? NotFound(new { message = $"לא נמצא משתתף עם מייל '{email}'." })
                : Ok(ParticipantMapper.ToResponse(p));
        }

        /// <summary>הוספת משתתף לאירוע. שלב ב' — שרת מייצר את ה-Id אוטומטית.</summary>
        [HttpPost("event/{eventId:int}")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status201Created)]
        public async Task<IActionResult> Add(int eventId, [FromBody] CreateParticipantRequest request)
        {
            var allParticipants = (await _personService.GetAllParticipantsAsync()).ToList();
            int newId = allParticipants.Any() ? allParticipants.Max(p => p.Id) + 1 : 1;

            var participant = ParticipantMapper.ToEntity(request, newId);
            await _participantService.AddParticipantToEventAsync(eventId, participant);

            return CreatedAtAction(nameof(GetById), new { id = participant.Id },
                ParticipantMapper.ToResponse(participant));
        }

        /// <summary>עדכון פרטי משתתף.</summary>
        [HttpPut("{id:int}")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateParticipantRequest request)
        {
            if (!IsManagerRole() && GetCallerId() != id)
                return Forbid();

            await _personService.UpdateParticipantPreferencesAsync(id, request.Name, request.Email, request.MailingPreferences);
            return Ok(ParticipantMapper.ToResponse(await _personService.GetParticipantByIdAsync(id)));
        }

        /// <summary>מחיקת משתתף.</summary>
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Manager")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete(int id)
        {
            await _personService.DeleteParticipantAsync(id);
            return NoContent();
        }

        /// <summary>
        /// שלב ד' — אישור/דחיית הגעה + בחירת העדפות דיוור.
        /// המשתתף בוחר לאילו ערוצים להירשם (EventChanges, DirectManagerMessages, PollCreated).
        /// </summary>
        [HttpPut("{participantId:int}/attendance")]
        [ProducesResponseType(typeof(ParticipantResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ConfirmAttendance(
            int participantId,
            [FromQuery] int eventId,
            [FromBody] ConfirmAttendanceRequest request)
        {
            if (!IsManagerRole() && GetCallerId() != participantId)
                return Forbid();

            await _participantService.ConfirmAttendanceAsync(
                participantId, eventId, request.IsAttending, request.SelectedPreferences);

            return Ok(ParticipantMapper.ToResponse(await _personService.GetParticipantByIdAsync(participantId)));
        }

        private int  GetCallerId()   => int.TryParse(User.FindFirstValue("userId"), out int id) ? id : 0;
        private bool IsManagerRole() => User.IsInRole("Manager");
    }
}
