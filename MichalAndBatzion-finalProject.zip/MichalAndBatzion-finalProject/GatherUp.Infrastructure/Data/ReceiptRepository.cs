using System.IO;
using System.Threading.Tasks;
using GatherUp.Core.DO;

namespace GatherUp.Infrastructure.Data
{
    // Receipt is immutable per spec — Update and Delete are forbidden.
    // Add copies the physical file to dedicated storage before persisting.
    public class ReceiptRepository : XmlRepository<Receipt>
    {
        private readonly string _receiptsStorageFolder;

        public ReceiptRepository(string baseFolder, string receiptsStorageFolder)
            : base(baseFolder)
        {
            if (!Directory.Exists(receiptsStorageFolder))
                Directory.CreateDirectory(receiptsStorageFolder);
            _receiptsStorageFolder = receiptsStorageFolder;
        }

        public override async Task AddAsync(Receipt receipt)
        {
            if (!string.IsNullOrWhiteSpace(receipt.FilePath) && File.Exists(receipt.FilePath))
            {
                string fileName   = Path.GetFileName(receipt.FilePath);
                string targetPath = Path.Combine(_receiptsStorageFolder, fileName);
                File.Copy(receipt.FilePath, targetPath, overwrite: true);

                receipt = new Receipt
                {
                    Id            = receipt.Id,
                    VendorId      = receipt.VendorId,
                    ReceiptNumber = receipt.ReceiptNumber,
                    FilePath      = targetPath,
                    Amount        = receipt.Amount,
                    Date          = receipt.Date
                };
            }

            await base.AddAsync(receipt);
        }

        public override Task UpdateAsync(Receipt receipt) =>
            throw new Core.Exceptions.ReceiptLockedException(receipt.VendorId);

        public override Task DeleteAsync(int id) =>
            throw new Core.Exceptions.ReceiptLockedException(id);
    }
}
