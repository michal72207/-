using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GatherUp.Core.DO
{
    public class Participant : Person
    {
        [SetsRequiredMembers]
        public Participant() { }

        public bool? IsAttending { get; set; }
        public bool HasPaid { get; set; }
        public decimal AmountContributed { get; set; }
        public List<MailingPreference> MailingPreferences { get; set; } = new();
    }
}
