// Use GatherUp.Core.Exceptions.InvalidInputException directly.
