namespace GatherUp.Core.DO
{
    // העדפות דיוור — המשתתף בוחר אילו מיילים לקבל (שלב ד')
    public enum MailingPreference
    {
        // שינויים בפרטי האירוע
        EventChanges,
        // הודעות ישירות מהמנהל
        DirectManagerMessages,
        // התראות על סקרים חדשים
        PollCreated,
        // אישורי הגעה (לצורך מנגנון הנוטיפיקציה הפנימי)
        AttendanceConfirmed,
        // אישורי תשלום
        PaymentReceived
    }
}
