using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using GatherUp.Core.Interfaces;

namespace GatherUp.Core.DO
{
    public class Poll : IEntity
    {
        [XmlAttribute("id")]
        public int Id { get; set; }

        // קוד סקר ייחודי (שלב ה')
        public string Code        { get; set; } = string.Empty;
        public string Name        { get; set; } = string.Empty;
        public string? Description { get; set; }

        // תאריך סגירת השאלון (שלב א')
        public DateTime? ClosingDate { get; set; }

        // האם זהו שאלון מקדים (שלב א')
        public bool IsPreliminary { get; set; }

        public List<PollQuestion> Questions { get; set; } = new();
    }
}
