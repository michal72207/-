using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GatherUp.Core.Interfaces;

namespace GatherUp.Infrastructure.Data
{
    /// <summary>
    /// In-memory repository implementation. Thread-safe using lock for concurrent access protection.
    /// NOTE: Use XmlRepository for production persistence. MemoryRepository is for testing only.
    /// </summary>
    /// <typeparam name="T">Entity type implementing IEntity</typeparam>
    public class MemoryRepository<T> : IRepository<T> where T : class, IEntity
    {
        private readonly List<T> _data = new();
        private readonly object _lockObject = new(); // Thread safety lock

        /// <summary>Add entity to repository (thread-safe).</summary>
        public Task AddAsync(T entity)
        {
            lock (_lockObject)
            {
                _data.Add(entity);
            }
            return Task.CompletedTask;
        }

        /// <summary>Get entity by ID (thread-safe).</summary>
        public Task<T> GetByIdAsync(int id)
        {
            lock (_lockObject)
            {
                var item = _data.FirstOrDefault(x => x.Id == id)
                    ?? throw new KeyNotFoundException($"{typeof(T).Name} עם Id={id} לא נמצא");
                return Task.FromResult(item);
            }
        }

        /// <summary>Get all entities (thread-safe).</summary>
        public Task<IEnumerable<T>> GetAllAsync()
        {
            lock (_lockObject)
            {
                return Task.FromResult<IEnumerable<T>>(_data.ToList()); // Return copy to prevent external modification
            }
        }

        /// <summary>Update existing entity (thread-safe).</summary>
        public Task UpdateAsync(T entity)
        {
            lock (_lockObject)
            {
                var existing = _data.FirstOrDefault(x => x.Id == entity.Id)
                    ?? throw new KeyNotFoundException($"{typeof(T).Name} עם Id={entity.Id} לא נמצא");
                _data.Remove(existing);
                _data.Add(entity);
            }
            return Task.CompletedTask;
        }

        /// <summary>Delete entity by ID (thread-safe).</summary>
        public Task DeleteAsync(int id)
        {
            lock (_lockObject)
            {
                var existing = _data.FirstOrDefault(x => x.Id == id)
                    ?? throw new KeyNotFoundException($"{typeof(T).Name} עם Id={id} לא נמצא");
                _data.Remove(existing);
            }
            return Task.CompletedTask;
        }
    }
}
