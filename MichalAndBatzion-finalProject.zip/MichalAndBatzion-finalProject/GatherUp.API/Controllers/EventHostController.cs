using GatherUp.API.DTOs;
using GatherUp.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GatherUp.API.Controllers
{
    /// <summary>ניהול בעלי אירועים — קריאה.</summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EventHostController : ControllerBase
    {
        private readonly EventService _eventService;

        public EventHostController(EventService eventService)
        {
            _eventService = eventService;
        }

        /// <summary>מחזיר את כל בעלי האירועים.</summary>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventHostResponse>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll() =>
            Ok((await _eventService.GetAllHostsAsync()).Select(EventMapper.ToHostResponse));

        /// <summary>מחזיר בעל אירוע לפי מזהה.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(EventHostResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id) =>
            Ok(EventMapper.ToHostResponse(await _eventService.GetHostByIdAsync(id)));
    }
}
