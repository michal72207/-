using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GatherUp.Core.Exceptions;
using GatherUp.Core.DO;
using GatherUp.Core.Interfaces;

namespace GatherUp.BL
{
    public class EventService
    {
        private readonly IRepository<Event>        _eventRepo;
        private readonly IRepository<EventManager> _managerRepo;
        private readonly IRepository<EventHost>    _hostRepo;
        private readonly IRepository<Participant>  _participantRepo;
        private readonly IEmailService             _emailService;

        public EventService(
            IRepository<Event>        eventRepo,
            IRepository<EventManager> managerRepo,
            IRepository<EventHost>    hostRepo,
            IRepository<Participant>  participantRepo,
            IEmailService             emailService)
        {
            _eventRepo       = eventRepo;
            _managerRepo     = managerRepo;
            _hostRepo        = hostRepo;
            _participantRepo = participantRepo;
            _emailService    = emailService;
        }

        // שלב א' — יצירת אירוע עם שאלון מקדים אופציונלי
        public async Task<Event> CreateEventAsync(
            string name, DateTime date, string? location,
            decimal pricePerParticipant, int managerId, int hostId,
            string? invitationMessage = null, string? paymentDetails = null,
            int? preliminaryPollId = null)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new InvalidInputException(nameof(name), "event name cannot be empty");
            if (pricePerParticipant < 0)
                throw new InvalidInputException(nameof(pricePerParticipant), "price cannot be negative");

            await _managerRepo.GetByIdAsync(managerId);
            await _hostRepo.GetByIdAsync(hostId);

            var all = (await _eventRepo.GetAllAsync()).ToList();
            int newId = all.Any() ? all.Max(e => e.Id) + 1 : 1;

            var ev = new Event
            {
                Id                  = newId,
                Name                = name,
                Date                = date,
                Location            = location,
                PricePerParticipant = pricePerParticipant,
                EventManagerId      = managerId,
                EventHostId         = hostId,
                InvitationMessage   = invitationMessage,
                PaymentDetails      = paymentDetails,
                PreliminaryPollId   = preliminaryPollId,
                Status              = EventStatus.Planning
            };
            await _eventRepo.AddAsync(ev);
            return ev;
        }

        // שלב ג' — שליחת הזמנות עם תוכן מנהל + פרטי תשלום
        /// <summary>
        /// Send invitations to pending participants for event registration.
        /// </summary>
        /// <param name="eventId">ID of event to send invitations for</param>
        /// <param name="registrationLink">Registration URL for participants to confirm attendance</param>
        /// <throws>InvalidInputException if no pending participants exist</throws>
        public async Task SendInvitationsAsync(int eventId, string registrationLink)
        {
            var ev = await _eventRepo.GetByIdAsync(eventId);
            EnsureNotFinalized(ev);
            var allParticipants = (await _participantRepo.GetAllAsync()).ToList();

            var pending = allParticipants
                .Where(p => ev.ParticipantIds.Contains(p.Id) && p.IsAttending == null)
                .ToList();

            if (!pending.Any())
                throw new InvalidInputException(nameof(eventId), "no pending participants to invite");

            foreach (var p in pending)
            {
                try
                {
                    string body = BuildInvitationBody(p.Name, ev, registrationLink);
                    await _emailService.SendAsync(p.Email, $"הזמנה לאירוע: {ev.Name}", body);
                }
                catch (Exception ex)
                {
                    // Log but continue sending to other participants
                    System.Diagnostics.Debug.WriteLine($"Failed to send invitation to {p.Email}: {ex.Message}");
                }
            }

            if (ev.Status != EventStatus.Finalized)
                ev.Status = EventStatus.InvitationsSent;

            await _eventRepo.UpdateAsync(ev);
        }

        // שלב ג' — שליחת הזמנה לבעל האירוע (EventHost) בנפרד
        /// <summary>
        /// Send invitation message to event host.
        /// </summary>
        /// <param name="eventId">ID of event</param>
        /// <param name="hostMessageContent">Message content for the host</param>
        /// <throws>InvalidInputException if message is empty</throws>
        public async Task SendHostInvitationAsync(int eventId, string hostMessageContent)
        {
            var ev   = await _eventRepo.GetByIdAsync(eventId);
            EnsureNotFinalized(ev);
            var host = await _hostRepo.GetByIdAsync(ev.EventHostId);

            if (string.IsNullOrWhiteSpace(hostMessageContent))
                throw new InvalidInputException(nameof(hostMessageContent), "host message cannot be empty");

            try
            {
                await _emailService.SendAsync(host.Email, $"הזמנה מיוחדת — {ev.Name}", hostMessageContent);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to send host invitation for event {eventId}: {ex.Message}");
            }

            ev.HostInvitationSent = true;
            await _eventRepo.UpdateAsync(ev);
        }

        // שלב ג' — תזמון הזמנה לבעל האירוע
        public async Task ScheduleHostInvitationAsync(int eventId, DateTime scheduledAt)
        {
            var ev = await _eventRepo.GetByIdAsync(eventId);
            EnsureNotFinalized(ev);
            ev.HostInvitationScheduledAt = scheduledAt;
            await _eventRepo.UpdateAsync(ev);
        }

        public async Task<IEnumerable<Event>> GetEventsByManagerAsync(int managerId) =>
            (await _eventRepo.GetAllAsync()).Where(e => e.EventManagerId == managerId);

        public async Task<IEnumerable<Event>> GetEventsByParticipantAsync(int participantId) =>
            (await _eventRepo.GetAllAsync()).Where(e => e.ParticipantIds.Contains(participantId));

        public async Task<IEnumerable<Event>> GetEventsByHostAsync(int hostId) =>
            (await _eventRepo.GetAllAsync()).Where(e => e.EventHostId == hostId);

        public async Task<bool> IsEventManagerAsync(int eventId, int userId)
        {
            var ev = await _eventRepo.GetByIdAsync(eventId);
            return ev.EventManagerId == userId;
        }

        public Task<Event> GetByIdAsync(int id) => _eventRepo.GetByIdAsync(id);

        public Task<IEnumerable<Event>> GetAllAsync() => _eventRepo.GetAllAsync();

        public Task DeleteAsync(int eventId) => _eventRepo.DeleteAsync(eventId);

        public Task<EventHost> GetHostByIdAsync(int hostId) => _hostRepo.GetByIdAsync(hostId);

        public Task<IEnumerable<EventHost>> GetAllHostsAsync() => _hostRepo.GetAllAsync();

        public async Task UpdateDetailsAsync(int eventId, string? newName, string? newLocation, decimal? newPrice,
            string? invitationMessage = null, string? paymentDetails = null)
        {
            if (newPrice.HasValue && newPrice.Value < 0)
                throw new InvalidInputException(nameof(newPrice), "price cannot be negative");

            var ev = await _eventRepo.GetByIdAsync(eventId);
            EnsureNotFinalized(ev);
            if (newName     != null) ev.Name     = newName;
            if (newLocation != null) ev.Location = newLocation;
            if (newPrice    != null) ev.PricePerParticipant = newPrice.Value;
            if (invitationMessage != null) ev.InvitationMessage = invitationMessage;
            if (paymentDetails   != null) ev.PaymentDetails    = paymentDetails;
            await _eventRepo.UpdateAsync(ev);
        }

        private static void EnsureNotFinalized(Event ev)
        {
            if (ev.Status == EventStatus.Finalized)
                throw new InvalidInputException(nameof(ev.Status), "event is finalized and cannot be changed");
        }

        private static string BuildInvitationBody(string participantName, Event ev, string link)
        {
            string custom  = ev.InvitationMessage ?? $"אנו שמחים להזמין אותך לאירוע {ev.Name}.";
            string payment = ev.PaymentDetails != null
                ? $"\n💰 סכום לתשלום: {ev.PricePerParticipant}₪\n💳 אפשרויות תשלום: {ev.PaymentDetails}"
                : $"\n💰 סכום לתשלום: {ev.PricePerParticipant}₪";
            return $"שלום {participantName},\n\n{custom}\n\n📅 תאריך: {ev.Date:dd/MM/yyyy}\n" +
                   $"📍 מיקום: {ev.Location ?? "טרם נקבע"}{payment}\n\n" +
                   $"לאישור הגעה ותשלום: {link}\n\nבברכה,\nמערכת GatherUp";
        }
    }
}
