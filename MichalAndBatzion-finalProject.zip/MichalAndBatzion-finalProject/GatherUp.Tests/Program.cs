using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using GatherUp.BL;
using GatherUp.Core.DO;
using GatherUp.Infrastructure.Data;

namespace GatherUp.Tests
{
    /// <summary>
    /// End-to-end integration test harness for GatherUp event management system.
    /// Tests complete workflows: event creation, participant management, polls, payments, vendors, receipts, and notifications.
    /// </summary>
    class Program
    {
        private static List<string> TestResults = new();
        private static int PassedTests = 0;
        private static int FailedTests = 0;

        static async Task Main(string[] args)
        {
            string baseDir        = AppDomain.CurrentDomain.BaseDirectory;
            string xmlFolder      = Path.Combine(baseDir, "XMLData");
            string receiptsFolder = Path.Combine(baseDir, "ReceiptsStorage");
            string emailsFolder   = Path.Combine(baseDir, "EmailsLog");

            // Initialize repositories
            var eventRepo       = new XmlRepository<Event>(xmlFolder);
            var participantRepo = new XmlRepository<Participant>(xmlFolder);
            var vendorRepo      = new XmlRepository<VendorAllocation>(xmlFolder);
            var pollRepo        = new XmlRepository<Poll>(xmlFolder);
            var managerRepo     = new XmlRepository<EventManager>(xmlFolder);
            var hostRepo        = new XmlRepository<EventHost>(xmlFolder);
            var receiptRepo     = new ReceiptRepository(xmlFolder, receiptsFolder);
            var emailService    = new FileEmailService(emailsFolder);

            // Initialize data if needed
            if (!File.Exists(Path.Combine(xmlFolder, "Events.xml")))
                await InitializeData.InitializeAsync(eventRepo, participantRepo, vendorRepo, pollRepo, managerRepo, hostRepo);

            // Create service layer
            var notifier           = new EventNotifierService(participantRepo, managerRepo, eventRepo, emailService);
            var participantService = new ParticipantService(participantRepo, eventRepo, emailService, notifier);
            var financeService     = new FinanceService(participantRepo, vendorRepo, receiptRepo, eventRepo, emailService, notifier);
            var pollService        = new PollService(pollRepo, eventRepo, participantRepo, emailService, notifier);
            var eventService       = new EventService(eventRepo, managerRepo, hostRepo, participantRepo, emailService);
            var personService      = new PersonService(participantRepo, managerRepo, hostRepo);

            try
            {
                // ═══════════════════════════════════════════════════════════════
                // STEP 1: Create Event
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 1: Create Event");
                var newEvent = new Event
                {
                    Id = 999,
                    Name = "E2E Test Event",
                    Date = DateTime.Now.AddDays(30),
                    Location = "Test Location",
                    PricePerParticipant = 150,
                    EventManagerId = 100,
                    EventHostId = 10,
                    Status = EventStatus.Planning
                };
                await eventRepo.AddAsync(newEvent);
                var createdEvent = await eventRepo.GetByIdAsync(999);
                Assert(createdEvent != null, "Event created successfully", "Event creation failed");
                if (createdEvent != null)
                {
                    Assert(createdEvent.Name == "E2E Test Event", "Event name matches", "Event name mismatch");
                    Assert(createdEvent.Status == EventStatus.Planning, "Event status is Planning", "Event status incorrect");
                }
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 2: Create Poll
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 2: Create Poll");
                var poll = await pollService.CreatePollAsync(999, "Test Poll",
                    new List<(string, List<string>)>
                    {
                        ("Location?", new List<string> { "Option A", "Option B" }),
                        ("Time?", new List<string> { "10:00", "15:00" })
                    });
                Assert(poll != null, "Poll created successfully", "Poll creation failed");
                if (poll != null)
                {
                    Assert(poll.Questions.Count == 2, "Poll has 2 questions", "Poll question count incorrect");
                    var eventWithPoll = await eventRepo.GetByIdAsync(999);
                    Assert(eventWithPoll?.PollIds.Contains(poll.Id) ?? false, "Poll linked to event", "Poll event linkage failed");
                }
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 3: Add Participants
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 3: Add Participants");
                var p1 = new Participant
                {
                    Id = 2001,
                    Name = "Test User 1",
                    Email = "test1@example.com",
                    MailingPreferences = new List<MailingPreference> { MailingPreference.EventChanges }
                };
                var p2 = new Participant
                {
                    Id = 2002,
                    Name = "Test User 2",
                    Email = "test2@example.com",
                    MailingPreferences = new List<MailingPreference> { MailingPreference.PollCreated }
                };
                await participantService.AddParticipantToEventAsync(999, p1);
                await participantService.AddParticipantToEventAsync(999, p2);
                var evt = await eventRepo.GetByIdAsync(999);
                Assert(evt?.ParticipantIds.Contains(2001) ?? false, "Participant 1 added to event", "Participant 1 not in event");
                Assert(evt?.ParticipantIds.Contains(2002) ?? false, "Participant 2 added to event", "Participant 2 not in event");
                Assert(evt?.ParticipantIds.Count == 2, "Event has exactly 2 participants", "Participant count mismatch");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 4: Submit Poll Responses
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 4: Submit Poll Responses");
                if (poll != null)
                {
                    await pollService.SubmitVoteAsync(poll.Id, 1, 2001, "Option A");
                    await pollService.SubmitVoteAsync(poll.Id, 2, 2001, "10:00");
                    await pollService.SubmitVoteAsync(poll.Id, 1, 2002, "Option B");
                    await pollService.SubmitVoteAsync(poll.Id, 2, 2002, "15:00");
                    var pollResults = await pollService.GetPollResultsAsync(poll.Id);
                    Assert(pollResults != null, "Poll results retrieved", "Poll results retrieval failed");
                    if (pollResults != null)
                    {
                        Assert(pollResults.QuestionResults.Count() == 2, "Poll has results for both questions", "Poll results count incorrect");
                    }
                }
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 5: Finalize Event
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 5: Finalize Event");
                var finalEvent = await eventRepo.GetByIdAsync(999);
                if (finalEvent != null)
                {
                    finalEvent.Status = EventStatus.Finalized;
                    await eventRepo.UpdateAsync(finalEvent);
                }
                var finalizedEvent = await eventRepo.GetByIdAsync(999);
                Assert(finalizedEvent?.Status == EventStatus.Finalized, "Event finalized successfully", "Event finalization failed");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 6: Send Invitations
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 6: Send Invitations");
                // Note: This would fail since event is already finalized, so we test with a new event
                var inviteEvent = new Event
                {
                    Id = 998,
                    Name = "Invite Test Event",
                    Date = DateTime.Now.AddDays(30),
                    Location = "Test",
                    PricePerParticipant = 100,
                    EventManagerId = 100,
                    EventHostId = 10,
                    Status = EventStatus.Planning,
                    ParticipantIds = new List<int> { 2001, 2002 }
                };
                await eventRepo.AddAsync(inviteEvent);
                var p3 = new Participant
                {
                    Id = 2003,
                    Name = "Pending User",
                    Email = "pending@example.com",
                    IsAttending = null,
                    MailingPreferences = new List<MailingPreference>()
                };
                await participantRepo.AddAsync(p3);
                var eventWithPending = await eventRepo.GetByIdAsync(998);
                eventWithPending.ParticipantIds.Add(2003);
                await eventRepo.UpdateAsync(eventWithPending);
                
                await eventService.SendInvitationsAsync(998, "https://gatherup.app/invite/998");
                var inviteSentEvent = await eventRepo.GetByIdAsync(998);
                Assert(inviteSentEvent.Status == EventStatus.InvitationsSent, "Invitations sent status updated", "Invitation status not updated");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 7: Register Participants (Confirm Attendance)
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 7: Register Participants (RSVP)");
                await participantService.ConfirmAttendanceAsync(2001, 999, isAttending: true,
                    new List<MailingPreference> { MailingPreference.EventChanges, MailingPreference.AttendanceConfirmed });
                await participantService.ConfirmAttendanceAsync(2002, 999, isAttending: true,
                    new List<MailingPreference> { MailingPreference.PaymentReceived });
                var p1Check = await participantRepo.GetByIdAsync(2001);
                var p2Check = await participantRepo.GetByIdAsync(2002);
                Assert(p1Check.IsAttending == true, "Participant 1 confirmed attendance", "Participant 1 attendance not confirmed");
                Assert(p2Check.IsAttending == true, "Participant 2 confirmed attendance", "Participant 2 attendance not confirmed");
                Assert(p1Check.MailingPreferences.Contains(MailingPreference.AttendanceConfirmed), "Participant 1 has AttendanceConfirmed", "AttendanceConfirmed preference not set");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 8: Record Payments
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 8: Record Payments");
                await financeService.RegisterPaymentAsync(2001, 999, 150);
                await financeService.RegisterPaymentAsync(2002, 999, 150);
                var p1Payment = await participantRepo.GetByIdAsync(2001);
                var p2Payment = await participantRepo.GetByIdAsync(2002);
                Assert(p1Payment.HasPaid == true, "Participant 1 payment recorded", "Participant 1 payment not recorded");
                Assert(p2Payment.HasPaid == true, "Participant 2 payment recorded", "Participant 2 payment not recorded");
                Assert(p1Payment.AmountContributed == 150, "Participant 1 amount correct", "Participant 1 amount incorrect");
                Assert(p2Payment.AmountContributed == 150, "Participant 2 amount correct", "Participant 2 amount incorrect");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 9: Add Vendors
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 9: Add Vendors");
                var vendor1 = await financeService.AddVendorToEventAsync(999, "Catering", 800);
                var vendor2 = await financeService.AddVendorToEventAsync(999, "Decorations", 500);
                Assert(vendor1 != null, "Vendor 1 created", "Vendor 1 creation failed");
                Assert(vendor2 != null, "Vendor 2 created", "Vendor 2 creation failed");
                Assert(vendor1?.Name == "Catering", "Vendor 1 name correct", "Vendor 1 name incorrect");
                Assert(vendor2?.AmountOwed == 500, "Vendor 2 debt correct", "Vendor 2 debt incorrect");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 10: Upload Receipts
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 10: Upload Receipts");
                string dummyFile = Path.Combine(baseDir, "receipt_e2e.txt");
                File.WriteAllText(dummyFile, "Receipt #RCP-E2E-001\nCatering services: 800₪");
                if (vendor1 != null)
                {
                    var receipt = new Receipt
                    {
                        Id = 5001,
                        VendorId = vendor1.Id,
                        ReceiptNumber = "RCP-E2E-001",
                        FilePath = dummyFile,
                        Amount = 800,
                        Date = DateTime.Now
                    };
                    await financeService.AddReceiptAsync(receipt, vendor1.Id);
                }
                var vendor1Check = await vendorRepo.GetByIdAsync(vendor1?.Id ?? 0);
                Assert(vendor1Check?.AmountOwed == 0, "Vendor 1 debt cleared by receipt", "Vendor 1 debt not cleared");
                Assert(vendor1Check?.IsPaid == true, "Vendor 1 marked as paid", "Vendor 1 not marked paid");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // STEP 11: Send Notifications
                // ═══════════════════════════════════════════════════════════════
                Print("STEP 11: Send Notifications (Integrated)");
                // Notifications are sent automatically during operations above
                // Verify email log has entries
                string emailLog = Path.Combine(emailsFolder, "emails.log");
                Assert(File.Exists(emailLog), "Email log exists", "Email log not created");
                var logContent = File.ReadAllText(emailLog);
                Assert(logContent.Length > 0, "Email log has entries", "Email log is empty");
                Assert(logContent.Contains("test1@example.com"), "Notification sent to participant 1", "No notification for participant 1");
                Assert(logContent.Contains("test2@example.com"), "Notification sent to participant 2", "No notification for participant 2");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // Financial Summary Verification
                // ═══════════════════════════════════════════════════════════════
                Print("Financial Summary Verification");
                var finSummary = await financeService.GetFinancialSummaryAsync(999);
                Assert(finSummary != null, "Financial summary retrieved", "Financial summary retrieval failed");
                Assert(finSummary.TotalIncome == 300, $"Total income correct (got {finSummary.TotalIncome})", "Total income incorrect");
                Console.WriteLine($"  Total Income: {finSummary.TotalIncome}₪");
                Console.WriteLine($"  Total Expenses: {finSummary.TotalExpenses}₪");
                Console.WriteLine($"  Balance: {finSummary.Balance}₪");
                Console.WriteLine();

                // ═══════════════════════════════════════════════════════════════
                // Data Persistence Verification
                // ═══════════════════════════════════════════════════════════════
                Print("Data Persistence Verification");
                var persistedEvent = await eventRepo.GetByIdAsync(999);
                Assert(persistedEvent != null, "Event persisted to XML", "Event not persisted");
                Assert(persistedEvent?.ParticipantIds.Count == 2, "Event participants persisted", "Event participants not persisted");
                
                var allParticipants = await participantRepo.GetAllAsync();
                Assert(allParticipants.Count() > 0, "Participants persisted", "Participants not persisted");
                
                var allVendors = await vendorRepo.GetAllAsync();
                Assert(allVendors.Count() > 0, "Vendors persisted", "Vendors not persisted");
                Console.WriteLine();

                // Print summary
                PrintSummary();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n❌ CRITICAL ERROR: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                Console.ResetColor();
                FailedTests++;
            }

            // Output files location
            Console.WriteLine();
            Print("Test Artifacts");
            Console.WriteLine($"  📧 Emails:     {Path.Combine(Directory.GetCurrentDirectory(), "EmailsLog", "emails.log")}");
            Console.WriteLine($"  💾 XML Data:   {Path.Combine(Directory.GetCurrentDirectory(), "XMLData")}");
            Console.WriteLine($"  🧾 Receipts:   {Path.Combine(Directory.GetCurrentDirectory(), "ReceiptsStorage")}");
        }

        /// <summary>
        /// Assert helper method for test validation.
        /// </summary>
        static void Assert(bool condition, string successMsg, string failureMsg)
        {
            if (condition)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"  ✓ {successMsg}");
                Console.ResetColor();
                PassedTests++;
                TestResults.Add($"✓ {successMsg}");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"  ✗ {failureMsg}");
                Console.ResetColor();
                FailedTests++;
                TestResults.Add($"✗ {failureMsg}");
            }
        }

        /// <summary>
        /// Print section header.
        /// </summary>
        static void Print(string title)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\n=== {title} ===");
            Console.ResetColor();
        }

        /// <summary>
        /// Print test summary report.
        /// </summary>
        static void PrintSummary()
        {
            Console.WriteLine("\n" + new string('═', 60));
            Print("INTEGRATION TEST SUMMARY");
            Console.WriteLine($"  Passed: {PassedTests}");
            Console.WriteLine($"  Failed: {FailedTests}");
            Console.WriteLine($"  Total:  {PassedTests + FailedTests}");
            
            if (FailedTests == 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n  ✅ ALL TESTS PASSED - System Ready for Production");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n  ❌ {FailedTests} TEST(S) FAILED - Review Required");
                Console.ResetColor();
            }
            Console.WriteLine(new string('═', 60));
        }
    }
}
